package com.noru.ai

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity: FlutterActivity() {
    private val channel = "noru.ai/overlay"
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channel).setMethodCallHandler { call, result ->
            when (call.method) {
                "hasOverlayPermission" -> result.success(Settings.canDrawOverlays(this))
                "requestOverlayPermission" -> { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))); result.success(true) }
                "startOverlay" -> { if (!Settings.canDrawOverlays(this)) { result.error("NO_PERMISSION","Overlay permission required",null); return@setMethodCallHandler }; startForegroundService(Intent(this, OverlayService::class.java)); result.success(true) }
                "stopOverlay" -> { stopService(Intent(this, OverlayService::class.java)); result.success(true) }
                "isOverlayEnabled" -> result.success(OverlayService.running)
                else -> result.notImplemented()
            }
        }
    }
}
