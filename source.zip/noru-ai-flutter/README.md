# Noru AI — Flutter Android

Flutter companion app for Noru AI with NoruUI Liquid Glass and an Android floating overlay button.

## Requirements
- Flutter stable
- Android SDK 35
- JDK 17+
- A real Android device/emulator

## Connect to the Vercel backend
The APK does **not** contain the Gemini API key. Pass only your public backend URL at build/run time:

```bash
flutter pub get
flutter run --dart-define=API_BASE_URL=https://YOUR-VERCEL-DOMAIN.vercel.app
```

Build release APK:

```bash
flutter build apk --release --dart-define=API_BASE_URL=https://YOUR-VERCEL-DOMAIN.vercel.app
```

APK output:
`build/app/outputs/flutter-apk/app-release.apk`

## Floating button
1. Open Noru AI.
2. Tap the layers/floating icon in the top bar.
3. Android opens **Display over other apps** permission.
4. Allow Noru AI.
5. Tap the floating icon again to start it.
6. The `N` button can be dragged over other apps/games.
7. Tap it to open the Noru AI panel or full app.

Android may restrict overlays for certain apps/games or device battery policies.

## Vercel API contract
The Flutter app sends:

```json
{
  "message": "Halo",
  "name": "Daffa",
  "history": []
}
```

Expected response:

```json
{
  "text": "Halo Daffa!"
}
```

Keep `GEMINI_API_KEY` only in Vercel Environment Variables.

## GitHub
Create a repository, then:

```bash
git init
git add .
git commit -m "Initial Noru AI Flutter app"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/noru-ai-flutter.git
git push -u origin main
```

## Notes
The Android overlay is implemented natively through a Flutter MethodChannel + Android foreground service. The overlay itself never needs the Gemini API key.


## GitHub Actions
The Android project includes the Flutter Gradle plugin loader and a self-contained `android/gradlew` bootstrap script so `flutter build apk` can run on GitHub Actions without relying on a missing wrapper JAR.
