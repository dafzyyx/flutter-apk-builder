# Noru AI — Flutter Android

Flutter 3.41.9 / Android target 35 companion app for Noru AI.

## Features

- NoruUI Liquid Glass chat UI
- User profile name + avatar
- Vercel `/api/chat` backend
- No Gemini API key inside the APK
- Android floating overlay bubble using `SYSTEM_ALERT_WINDOW`
- Native foreground service for the floating bubble
- Bubble can stay above normal apps such as browsers, video players, and games when Android grants overlay permission
- GitHub Actions release APK build

## Important Android behavior

The first time the user enables the floating assistant, Android opens **Display over other apps**. The user must allow it.

The app starts the overlay service from the visible Flutter activity. This matters on Android 15+, where background foreground-service starts are more restricted.

The native overlay is intentionally separate from Flutter's main Activity: the bubble is an Android `TYPE_APPLICATION_OVERLAY` window, while the full Noru AI chat remains Flutter.

## GitHub Actions secret

Add this repository secret:

`NORU_API_BASE_URL=https://YOUR-VERCEL-DOMAIN.vercel.app`

The secret is only the public backend base URL. Never put `GEMINI_API_KEY` in the Flutter repository or APK.

## Build locally

```bash
flutter clean
flutter pub get
flutter analyze
flutter build apk --release --dart-define=API_BASE_URL=https://YOUR-VERCEL-DOMAIN.vercel.app
```

APK:

`build/app/outputs/flutter-apk/app-release.apk`

## GitHub

Push the project to GitHub. The workflow pins Flutter 3.41.9 and Java 17 so the CI environment is deterministic.
