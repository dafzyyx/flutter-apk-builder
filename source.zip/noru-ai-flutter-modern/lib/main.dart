import 'dart:convert';
import 'dart:io';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'config/test_config.dart';

const apiBaseUrl = String.fromEnvironment('API_BASE_URL', defaultValue: 'https://YOUR-VERCEL-DOMAIN.vercel.app');
// For production, keep Gemini authentication on the Vercel backend.
// A supplied NORU_GEMINI_API_KEY is only a local/test configuration value.
const testGeminiKey = String.fromEnvironment('NORU_GEMINI_API_KEY', defaultValue: '');
// Kept only to validate the test configuration during builds; never send this as a Gemini credential.
const _testCredentialConfigured = dummyApiKey.isNotEmpty;
const overlayChannel = MethodChannel('noru.ai/overlay');

void main() {
  assert(_testCredentialConfigured);
  runApp(const NoruApp());
}

class NoruApp extends StatelessWidget {
  const NoruApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Noru AI',
    theme: ThemeData(useMaterial3: true, brightness: Brightness.light, fontFamily: 'sans-serif'),
    home: const HomePage(),
  );
}

class ProfileData {
  final String name;
  final String? avatar;
  const ProfileData({required this.name, this.avatar});
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final _input = TextEditingController();
  final _scroll = ScrollController();
  final List<Map<String, String>> _messages = [];
  ProfileData _profile = const ProfileData(name: 'Pengguna');
  bool _loading = false;
  bool _overlayEnabled = false;

  @override
  void initState() { super.initState(); _loadProfile(); _loadOverlay(); }
  @override void dispose() { _input.dispose(); _scroll.dispose(); super.dispose(); }

  Future<void> _loadProfile() async {
    final p = await SharedPreferences.getInstance();
    setState(() => _profile = ProfileData(name: p.getString('name') ?? 'Pengguna', avatar: p.getString('avatar')));
  }
  Future<void> _loadOverlay() async {
    try { final v = await overlayChannel.invokeMethod<bool>('isOverlayEnabled') ?? false; setState(() => _overlayEnabled = v); } catch (_) {}
  }
  Future<void> _toggleOverlay() async {
    try {
      final allowed = await overlayChannel.invokeMethod<bool>('hasOverlayPermission') ?? false;
      if (!allowed) { await overlayChannel.invokeMethod('requestOverlayPermission'); return; }
      if (_overlayEnabled) { await overlayChannel.invokeMethod('stopOverlay'); } else { await overlayChannel.invokeMethod('startOverlay'); }
      await _loadOverlay();
    } catch (_) { _snack('Overlay belum tersedia di perangkat ini.'); }
  }

  Future<void> _send([String? preset]) async {
    final text = (preset ?? _input.text).trim();
    if (text.isEmpty || _loading) return;
    _input.clear();
    setState(() { _messages.add({'role': 'user', 'text': text}); _loading = true; });
    _scrollDown();
    try {
      final history = _messages.map((m) => {'role': m['role'], 'text': m['text']}).toList();
      final r = await http.post(Uri.parse('$apiBaseUrl/api/chat'), headers: {
        'Content-Type':'application/json',
        if (testGeminiKey.trim().isNotEmpty) 'X-Noru-Test-Key': testGeminiKey.trim(),
      }, body: jsonEncode({'message': text, 'name': _profile.name, 'history': history})).timeout(const Duration(seconds: 45));
      final data = jsonDecode(r.body);
      if (r.statusCode >= 400) throw Exception(data['error'] ?? 'HTTP ${r.statusCode}');
      final answer = (data['text'] ?? data['response'] ?? data['answer'] ?? '').toString();
      if (answer.isEmpty) throw Exception('AI tidak mengembalikan jawaban.');
      setState(() => _messages.add({'role':'model','text':answer}));
    } catch (e) { setState(() => _messages.add({'role':'model','text':'Terjadi kesalahan: $e'})); }
    finally { setState(() => _loading = false); _scrollDown(); }
  }
  void _scrollDown() => WidgetsBinding.instance.addPostFrameCallback((_) { if (_scroll.hasClients) _scroll.animateTo(_scroll.position.maxScrollExtent, duration: const Duration(milliseconds:250), curve: Curves.easeOut); });
  void _snack(String s) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s), behavior: SnackBarBehavior.floating));

  Future<void> _editProfile() async {
    final name = TextEditingController(text: _profile.name);
    XFile? picked;
    final result = await showModalBottomSheet<Map<String, dynamic>>(
      context: context, isScrollControlled: true, backgroundColor: Colors.transparent,
      builder: (_) => StatefulBuilder(builder: (context, setModal) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
        child: ClipRRect(borderRadius: const BorderRadius.vertical(top: Radius.circular(32)), child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 24, sigmaY: 24), child: Container(
            padding: const EdgeInsets.fromLTRB(22, 22, 22, 28), color: Colors.white.withOpacity(.86),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Row(children: [const Expanded(child: Text('Profile', style: TextStyle(fontSize:20,fontWeight:700))), IconButton(onPressed:()=>Navigator.pop(context), icon:const Icon(Icons.close))]),
              const SizedBox(height: 10),
              CircleAvatar(radius: 48, backgroundImage: picked != null ? FileImage(File(picked!.path)) : (_profile.avatar != null ? MemoryImage(base64Decode(_profile.avatar!)) : const AssetImage('assets/ai-avatar.jpg')) as ImageProvider),
              TextButton(onPressed: () async { final f=await ImagePicker().pickImage(source:ImageSource.gallery,imageQuality:75,maxWidth:512); if(f!=null)setModal(()=>picked=f); }, child: const Text('Ganti foto')),
              TextField(controller:name, maxLength:40, decoration: const InputDecoration(labelText:'Nama', filled:true, border:OutlineInputBorder(borderRadius:BorderRadius.all(Radius.circular(16)),borderSide:BorderSide.none))),
              const SizedBox(height:14),
              SizedBox(width:double.infinity,height:48,child:FilledButton(onPressed:()=>Navigator.pop(context, {'name':name.text.trim(),'file':picked}), child:const Text('Simpan'))),
            ]),
          ),
        )),
      )),
    );
    if (result == null) return;
    final p=await SharedPreferences.getInstance(); String? avatar=_profile.avatar;
    final file=result['file'] as XFile?;
    if(file!=null) avatar=base64Encode(await File(file.path).readAsBytes());
    final newName=(result['name'] as String).isEmpty?'Pengguna':result['name'] as String;
    await p.setString('name',newName); if(avatar!=null) await p.setString('avatar',avatar);
    setState(()=>_profile=ProfileData(name:newName,avatar:avatar));
  }

  ImageProvider _userImage() => _profile.avatar != null ? MemoryImage(base64Decode(_profile.avatar!)) : const AssetImage('assets/ai-avatar.jpg');
  @override Widget build(BuildContext context) => Scaffold(
    backgroundColor: const Color(0xfff3f5f8),
    body: Stack(children:[
      Positioned(top:-120,right:-80,child:Container(width:280,height:280,decoration:BoxDecoration(shape:BoxShape.circle,color:Colors.white.withOpacity(.9),boxShadow:[BoxShadow(blurRadius:90,color:Colors.white.withOpacity(.9))]))),
      SafeArea(child: Column(children:[
        Padding(padding:const EdgeInsets.fromLTRB(14,10,14,10),child:ClipRRect(borderRadius:BorderRadius.circular(22),child:BackdropFilter(filter:ImageFilter.blur(sigmaX:20,sigmaY:20),child:Container(padding:const EdgeInsets.all(10),color:Colors.white.withOpacity(.68),child:Row(children:[
          const CircleAvatar(radius:21,backgroundImage:AssetImage('assets/ai-avatar.jpg')), const SizedBox(width:10), const Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('Noru AI',style:TextStyle(fontWeight:800)),Text('Gemini 3.5 Flash',style:TextStyle(fontSize:11,color:Colors.black54))])),
          IconButton(onPressed:_toggleOverlay,tooltip:'Floating button',icon:Icon(_overlayEnabled?Icons.layers_rounded:Icons.layers_outlined)),
          GestureDetector(onTap:_editProfile,child:CircleAvatar(radius:20,backgroundImage:_userImage())),
        ]))))),
        Expanded(child:_messages.isEmpty ? _welcome() : ListView.builder(controller:_scroll,padding:const EdgeInsets.fromLTRB(14,10,14,140),itemCount:_messages.length,itemBuilder:(c,i)=>_bubble(_messages[i]))),
        _composer(),
      ])),
    ]),
  );

  Widget _welcome()=>Center(child:SingleChildScrollView(padding:const EdgeInsets.all(24),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[
    Container(width:78,height:78,decoration:BoxDecoration(borderRadius:BorderRadius.circular(26),boxShadow:[BoxShadow(blurRadius:35,color:Colors.black.withOpacity(.08))]),child:ClipRRect(borderRadius:BorderRadius.circular(26),child:Image.asset('assets/ai-avatar.jpg',fit:BoxFit.cover))),
    const SizedBox(height:18), const Text('Apa yang bisa Noru AI bantu?',textAlign:TextAlign.center,style:TextStyle(fontSize:28,fontWeight:800,letterSpacing:-1.2)), const SizedBox(height:9),Text('Halo, ${_profile.name}. Tanya apa saja dan Noru AI akan membantu.',textAlign:TextAlign.center,style:const TextStyle(color:Colors.black54)),const SizedBox(height:22),
    Wrap(spacing:10,runSpacing:10,alignment:WrapAlignment.center,children:[_chip('Jelaskan AI dengan sederhana','Jelaskan AI dengan bahasa sederhana.'),_chip('Bantu coding','Buatkan contoh kode HTML sederhana.'),_chip('Buat ide','Berikan 5 ide project yang menarik.'),_chip('Belajar','Ajarkan saya sesuatu yang baru.')]),
  ]));
  Widget _chip(String title,String prompt)=>ActionChip(label:Text(title),onPressed:()=>_send(prompt),shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(15)));
  Widget _bubble(Map<String,String> m){final user=m['role']=='user'; return Align(alignment:user?Alignment.centerRight:Alignment.centerLeft,child:Container(margin:const EdgeInsets.only(bottom:12),constraints:BoxConstraints(maxWidth:MediaQuery.of(context).size.width*.82),child:Row(crossAxisAlignment:CrossAxisAlignment.end,mainAxisAlignment:user?MainAxisAlignment.end:MainAxisAlignment.start,children:[if(!user)const Padding(padding:EdgeInsets.only(right:7),child:CircleAvatar(radius:15,backgroundImage:AssetImage('assets/ai-avatar.jpg'))),Flexible(child:ClipRRect(borderRadius:BorderRadius.circular(20),child:BackdropFilter(filter:ImageFilter.blur(sigmaX:15,sigmaY:15),child:Container(padding:const EdgeInsets.symmetric(horizontal:15,vertical:12),decoration:BoxDecoration(color:user?const Color(0xff15171b).withOpacity(.94):Colors.white.withOpacity(.76),borderRadius:BorderRadius.circular(20),border:Border.all(color:Colors.white.withOpacity(.5))),child:Text(m['text']??'',style:TextStyle(color:user?Colors.white:Colors.black87,height:1.5))))),if(user)Padding(padding:const EdgeInsets.only(left:7),child:CircleAvatar(radius:15,backgroundImage:_userImage()))])));}
  Widget _composer()=>Padding(padding:const EdgeInsets.fromLTRB(12,8,12,12),child:ClipRRect(borderRadius:BorderRadius.circular(24),child:BackdropFilter(filter:ImageFilter.blur(sigmaX:24,sigmaY:24),child:Container(padding:const EdgeInsets.symmetric(horizontal:8,vertical:7),decoration:BoxDecoration(color:Colors.white.withOpacity(.78),border:Border.all(color:Colors.white.withOpacity(.75)),borderRadius:BorderRadius.circular(24),boxShadow:[BoxShadow(blurRadius:30,color:Colors.black.withOpacity(.08))]),child:Row(crossAxisAlignment:CrossAxisAlignment.end,children:[Expanded(child:TextField(controller:_input,minLines:1,maxLines:5,textInputAction:TextInputAction.new,onSubmitted:(_)=>_send(),decoration:const InputDecoration(hintText:'Tulis pesan ke Noru AI...',border:InputBorder.none,contentPadding:EdgeInsets.symmetric(horizontal:10,vertical:9)))),IconButton(onPressed:_loading?null:()=>_send(),style:IconButton.styleFrom(backgroundColor:const Color(0xff15171b),foregroundColor:Colors.white),icon:_loading?const SizedBox(width:19,height:19,child:CircularProgressIndicator(strokeWidth:2,color:Colors.white)):const Icon(Icons.arrow_upward_rounded))])))));
}
