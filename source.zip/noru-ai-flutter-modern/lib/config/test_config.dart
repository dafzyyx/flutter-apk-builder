/// Optional test credential configuration.
/// Put a real key only for local/testing builds. The APK does NOT fall back
/// silently when a supplied key is invalid: the API error is shown as an error.
const String dummyApiKey = 'AQ.Ab8RN6JooUuN2c4ayroJWlK2Ac81osRn1UcjPgteNKgIaWRAJA';

const String configuredApiKey = String.fromEnvironment(
  'NORU_GEMINI_API_KEY',
  defaultValue: '',
);

String get effectiveTestApiKey =>
    configuredApiKey.trim().isNotEmpty ? configuredApiKey.trim() : dummyApiKey;
