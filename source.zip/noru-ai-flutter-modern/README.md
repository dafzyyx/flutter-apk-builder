# Noru AI — Flutter Android Overlay

Flutter Android companion for Noru AI with a floating overlay/chat-head.

## API behavior
- Production chat goes to `API_BASE_URL/api/chat` (Vercel backend).
- `NORU_GEMINI_API_KEY` is optional and only for explicit local/test configuration.
- The included dummy value is **not** used as a silent fallback for Gemini.
- If a real key is supplied and the backend/API rejects it, the app shows the returned error instead of falling back to the dummy key.
- For production, keep the real Gemini secret in Vercel environment variables.

## GitHub Actions secrets
- `NORU_API_BASE_URL` = your Vercel backend URL
- Optional `NORU_GEMINI_API_KEY` = real test key if your backend is designed to accept `X-Noru-Test-Key`

The workflow pins Flutter 3.41.9, Java 17 and Gradle 8.10.2.
