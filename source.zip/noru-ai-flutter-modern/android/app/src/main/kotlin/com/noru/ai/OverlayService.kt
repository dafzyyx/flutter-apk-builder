package com.noru.ai

import android.app.*
import android.content.pm.ServiceInfo
import android.content.*
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.*
import android.widget.*

class OverlayService: Service() {
    companion object { var running = false }
    private var wm: WindowManager? = null
    private var bubble: View? = null
    override fun onCreate() {
        super.onCreate()
        running = true
        createChannel()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(42, notification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(42, notification())
        }
        showBubble()
    }
    private fun createChannel() { if(Build.VERSION.SDK_INT>=26) getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("noru_overlay","Noru AI Floating","low")) }
    private fun notification(): Notification = Notification.Builder(this,"noru_overlay").setContentTitle("Noru AI").setContentText("Floating button aktif").setSmallIcon(android.R.drawable.ic_dialog_info).setOngoing(true).build()
    private fun showBubble() {
        wm=getSystemService(WINDOW_SERVICE) as WindowManager
        val size=(56*resources.displayMetrics.density).toInt()
        val b=TextView(this).apply { text="N"; textSize=18f; setTextColor(Color.WHITE); gravity=Gravity.CENTER; background=GradientDrawable().apply { shape=GradientDrawable.OVAL; setColor(Color.rgb(17,19,24)) }; elevation=12f }
        b.setOnClickListener { showPanel() }
        b.setOnTouchListener(DragTouch(wm!!, b))
        bubble=b
        val type=if(Build.VERSION.SDK_INT>=26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val p=WindowManager.LayoutParams(size,size,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, -3).apply { gravity=Gravity.TOP or Gravity.START; x=20; y=220 }
        wm!!.addView(b,p)
    }
    private fun showPanel() {
        val panel=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(20,18,20,16); background=GradientDrawable().apply { cornerRadius=36f; setColor(Color.argb(245,250,250,252)); setStroke(1,Color.argb(35,0,0,0)) } }
        val title=TextView(this).apply { text="Noru AI"; textSize=18f; setTextColor(Color.rgb(17,19,24)); setTypeface(null,1) }
        val input=EditText(this).apply { hint="Tanya Noru AI..."; setSingleLine(false); maxLines=3 }
        val send=Button(this).apply { text="Buka Noru AI"; setOnClickListener { startActivity(Intent(this@OverlayService, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); removePanel(panel) } }
        panel.addView(title); panel.addView(input,LinearLayout.LayoutParams(-1,0,1f)); panel.addView(send)
        val sizeW=(310*resources.displayMetrics.density).toInt(); val sizeH=(220*resources.displayMetrics.density).toInt()
        val type=if(Build.VERSION.SDK_INT>=26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val p=WindowManager.LayoutParams(sizeW,sizeH,type,WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,-3).apply { gravity=Gravity.CENTER }
        wm!!.addView(panel,p)
    }
    private fun removePanel(v:View){try{wm?.removeView(v)}catch(_:Exception){}}
    override fun onDestroy(){running=false; try{wm?.removeView(bubble)}catch(_:Exception){}; super.onDestroy()}
    override fun onBind(intent:Intent?):IBinder?=null
    class DragTouch(private val wm:WindowManager,private val view:View):View.OnTouchListener{var dx=0;var dy=0;var sx=0f;var sy=0f;var down=0L;override fun onTouch(v:View,e:android.view.MotionEvent):Boolean{val p=v.layoutParams as WindowManager.LayoutParams;when(e.action){0->{dx=p.x;dy=p.y;sx=e.rawX;sy=e.rawY;down=System.currentTimeMillis();return true};2->{p.x=dx+(e.rawX-sx).toInt();p.y=dy+(e.rawY-sy).toInt();wm.updateViewLayout(view,p);return true};1->{if(System.currentTimeMillis()-down<220)v.performClick();return true}};return false}}
}
