# Noru Chat Flutter — perbaikan build

## Perbaikan yang dilakukan
- Menambahkan dependency `path_provider` yang dipakai di `lib/screens/chat_screen.dart` untuk menyimpan rekaman sementara. Tanpa dependency ini, build gagal saat kompilasi karena package tidak ditemukan.
- Memperbaiki workflow GitHub Actions agar menyiapkan Java 17 dan membuat folder Android sebelum mengambil dependency.
- Menambahkan langkah `flutter analyze` supaya error Dart terlihat jelas sebelum build APK.
- Artifact APK akan gagal dengan pesan jelas jika tidak ada file APK hasil build.
- Pengiriman Telegram tetap opsional; isi repository secrets `TELEGRAM_BOT_TOKEN` dan `TELEGRAM_CHAT_ID` jika ingin menggunakannya.

## Cara build
1. Upload isi ZIP ini ke repository GitHub (termasuk folder `.github`).
2. Pastikan branch bernama `main`, atau sesuaikan nama branch pada `.github/workflows/build-apk.yml`.
3. Buka **Actions → Build APK → Run workflow**. Bisa juga push commit ke `main`.
4. Jika sukses, unduh `noru-chat-apk` dari bagian **Artifacts** pada run workflow.
5. Jika gagal, buka langkah merah pertama di workflow; `flutter analyze` akan menunjukkan error Dart jika ada.

## Telegram (opsional)
Di repository GitHub buka **Settings → Secrets and variables → Actions** dan tambahkan:
- `TELEGRAM_BOT_TOKEN`
- `TELEGRAM_CHAT_ID`

Jangan menaruh token langsung di file source atau membagikannya kepada orang lain.

Catatan: environment di sini tidak menyediakan Flutter SDK/Android SDK, jadi build APK penuh tidak dapat dieksekusi lokal di sini. Workflow disiapkan untuk membangun di runner GitHub Actions.
