# Noru Japanese Dictionary — Flutter APK

Project Flutter siap dimasukkan ke GitHub/Flutter APK Builder.

## Fitur
- Search Jepang / kana / romaji / English
- Kanji + reading
- Definisi
- Part of speech
- JLPT tag jika tersedia
- Pronunciation Jepang dengan Text-to-Speech
- Favorit
- Riwayat pencarian
- Random word
- Copy hasil
- Light/Dark mode
- Responsive Material 3 UI
- Data online dari Jisho API

## Build
```bash
flutter pub get
flutter build apk --release
```

APK:
`build/app/outputs/flutter-apk/app-release.apk`

## Catatan API
App menggunakan endpoint pencarian kata Jisho yang tersedia publik. Jika API sedang rate-limited/down, pencarian akan menampilkan pesan error.
