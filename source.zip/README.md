# Noru Japanese Dictionary — Flutter APK

ZIP ini adalah project Flutter yang bisa di-upload sebagai **Flutter Project ZIP**
ke GitHub APK Builder.

## Build
Builder menjalankan:
1. `flutter pub get`
2. `flutter build apk --release`

Output:
`build/app/outputs/flutter-apk/app-release.apk`

## Fitur
- Search Jepang / kana / romaji / English
- Kanji + reading
- Definisi
- Part of speech
- JLPT tag jika tersedia
- Japanese Text-to-Speech
- Favorit
- Riwayat pencarian
- Random word
- Copy hasil
- Light/Dark mode
- Material 3
- Online dictionary API

## Catatan
Aplikasi membutuhkan koneksi internet untuk mengambil hasil kamus.
