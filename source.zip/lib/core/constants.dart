class AppConstants {
  static const String appName = "Noru Chat";
  static const String appVersion = "1.0.0";

  /// Alamat server Noru Chat di Pterodactyl.
  /// Contoh: "http://123.45.67.89:3000" atau "https://chat.domainkamu.com".
  /// JANGAN pakai domain PANEL Pterodactyl (mis. dewa.my-panel.biz.id) —
  /// itu bukan alamat server. Lihat tab Network server untuk IP:PORT yang benar.
  static const String baseUrl = "https://panel1.ikyhost.cloud:2439";
}
