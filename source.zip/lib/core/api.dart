import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'constants.dart';

// Alamat server diatur di satu tempat saja: AppConstants.baseUrl (lib/core/constants.dart).

class ApiException implements Exception {
  final String detail;
  final int status;
  ApiException(this.detail, this.status);
  @override
  String toString() => detail;
}

class Api {
  Api._();
  static final Api instance = Api._();

  String? token;
  Map<String, dynamic>? me; // {username, name}

  Future<void> loadToken() async {
    final sp = await SharedPreferences.getInstance();
    token = sp.getString("token");
  }

  Future<void> _saveToken(String t) async {
    token = t;
    final sp = await SharedPreferences.getInstance();
    await sp.setString("token", t);
  }

  Future<void> logout() async {
    token = null;
    me = null;
    final sp = await SharedPreferences.getInstance();
    await sp.remove("token");
  }

  Map<String, String> get _headers => {
        "Content-Type": "application/json",
        if (token != null) "Authorization": "Bearer $token",
      };

  Future<dynamic> _req(String method, String path, {Map<String, dynamic>? body}) async {
    final uri = Uri.parse("${AppConstants.baseUrl}/api$path");
    http.Response r;
    try {
      if (method == "GET") {
        r = await http.get(uri, headers: _headers).timeout(const Duration(seconds: 20));
      } else {
        r = await http
            .post(uri, headers: _headers, body: body != null ? jsonEncode(body) : null)
            .timeout(const Duration(seconds: 20));
      }
    } catch (e) {
      throw ApiException("Tidak bisa menghubungi server. Cek alamat server dan koneksi internet.", 0);
    }
    Map<String, dynamic> d = {};
    try {
      if (r.body.isNotEmpty) d = jsonDecode(r.body);
    } catch (_) {}
    if (r.statusCode >= 400) {
      throw ApiException(d["detail"]?.toString() ?? "Request gagal (${r.statusCode}).", r.statusCode);
    }
    return d;
  }

  Future<Map<String, dynamic>> register(String username, String password, String name) async {
    final d = await _req("POST", "/register", body: {"username": username, "password": password, "name": name});
    await _saveToken(d["token"]);
    me = d["user"];
    return d;
  }

  Future<Map<String, dynamic>> login(String username, String password) async {
    final d = await _req("POST", "/login", body: {"username": username, "password": password});
    await _saveToken(d["token"]);
    me = d["user"];
    return d;
  }

  Future<Map<String, dynamic>> fetchMe() async {
    final d = await _req("GET", "/me");
    me = d["user"];
    return d;
  }

  Future<List<dynamic>> searchUsers(String q) async {
    final d = await _req("GET", "/users?q=${Uri.encodeQueryComponent(q)}");
    return d["users"] ?? [];
  }

  Future<Map<String, dynamic>> openDm(String withUser) async {
    final d = await _req("POST", "/chats", body: {"with": withUser});
    return d["chat"];
  }

  Future<Map<String, dynamic>> createGroup(String name, List<String> members) async {
    final d = await _req("POST", "/groups", body: {"name": name, "members": members});
    return d["chat"];
  }

  Future<Map<String, dynamic>> messages(String chatId) async {
    return await _req("GET", "/chats/$chatId/messages");
  }

  Future<void> sendText(String chatId, String text) async {
    await _req("POST", "/chats/$chatId/messages", body: {"text": text});
  }

  /// [dataUrl] format "data:<mime>;base64,<...>"
  Future<void> sendFile(String chatId, String dataUrl) async {
    await _req("POST", "/chats/$chatId/messages", body: {"file": dataUrl});
  }

  Future<void> markRead(String chatId) async {
    await _req("POST", "/chats/$chatId/read", body: {});
  }

  Future<void> typing(String chatId) async {
    try {
      await _req("POST", "/chats/$chatId/typing", body: {});
    } catch (_) {}
  }

  String fileUrl(String fileId) => "${AppConstants.baseUrl}/files/$fileId?token=$token";

  /// Membuka koneksi SSE ke /api/events dan mengembalikan stream event (name,data).
  StreamSubscription<void>? _sseSub;
  http.Client? _sseClient;

  Stream<MapEntry<String, dynamic>> connectEvents() {
    final controller = StreamController<MapEntry<String, dynamic>>.broadcast();
    _startSse(controller);
    return controller.stream;
  }

  Future<void> _startSse(StreamController<MapEntry<String, dynamic>> controller) async {
    await _sseSub?.cancel();
    _sseClient?.close();
    final client = http.Client();
    _sseClient = client;
    try {
      final req = http.Request("GET", Uri.parse("${AppConstants.baseUrl}/api/events?token=$token"));
      final resp = await client.send(req);
      String evName = "message";
      final buf = StringBuffer();
      _sseSub = resp.stream.transform(utf8.decoder).transform(const LineSplitter()).listen((line) {
        if (line.startsWith("event:")) {
          evName = line.substring(6).trim();
        } else if (line.startsWith("data:")) {
          buf.write(line.substring(5).trim());
        } else if (line.isEmpty) {
          if (buf.isNotEmpty) {
            try {
              final data = jsonDecode(buf.toString());
              controller.add(MapEntry(evName, data));
            } catch (_) {}
          }
          buf.clear();
          evName = "message";
        }
      }, onDone: () {
        // Server putus / jaringan hilang: coba sambung lagi setelah jeda.
        Future.delayed(const Duration(seconds: 3), () {
          if (!controller.isClosed) _startSse(controller);
        });
      }, onError: (_) {
        Future.delayed(const Duration(seconds: 3), () {
          if (!controller.isClosed) _startSse(controller);
        });
      });
    } catch (_) {
      Future.delayed(const Duration(seconds: 3), () {
        if (!controller.isClosed) _startSse(controller);
      });
    }
  }

  void closeEvents() {
    _sseSub?.cancel();
    _sseClient?.close();
  }
}
