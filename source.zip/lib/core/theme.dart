import 'package:flutter/material.dart';

// Palet neubrutalism senada dengan web Noru Chat / Noru Monitor.
class AppColors {
  static const ink = Color(0xFF111111);
  static const bg = Color(0xFFFFF4D6);
  static const chatBg = Color(0xFFFFEAB0);
  static const green = Color(0xFF25D366);
  static const yellow = Color(0xFFFFDE59);
  static const pink = Color(0xFFFF90E8);
  static const blue = Color(0xFF7CC4FF);
  static const red = Color(0xFFFF6B6B);
}

class AppTheme {
  static final ThemeData lightTheme = ThemeData(
    useMaterial3: true,
    scaffoldBackgroundColor: AppColors.bg,
    colorScheme: ColorScheme.fromSeed(seedColor: AppColors.green, brightness: Brightness.light, surface: AppColors.bg),
    fontFamily: "Roboto",
    dividerColor: AppColors.ink,
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: Colors.white,
      border: OutlineInputBorder(borderRadius: BorderRadius.zero, borderSide: const BorderSide(color: AppColors.ink, width: 2.5)),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.zero, borderSide: const BorderSide(color: AppColors.ink, width: 2.5)),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.zero, borderSide: const BorderSide(color: AppColors.ink, width: 3)),
    ),
  );

  // Catatan: gaya neubrutalism di app ini sengaja dipertahankan sama persis
  // di mode gelap (border hitam tebal + kartu putih) karena itu ciri khasnya;
  // kalau mau dark mode sungguhan, ganti scaffoldBackgroundColor & kartu di sini.
  static final ThemeData darkTheme = lightTheme;
}
