import 'dart:async';
import 'package:flutter/material.dart';
import '../core/api.dart';

/// Memegang satu koneksi SSE untuk seluruh app (bukan satu per layar),
/// plus daftar chat yang dipakai ulang oleh HomeScreen & ChatScreen.
class ChatProvider extends ChangeNotifier {
  final Map<String, dynamic> chats = {};
  bool loading = true;
  String error = "";
  StreamSubscription? _sub;

  /// Layar lain (mis. ChatScreen) bisa dengar event mentah di sini juga,
  /// supaya tidak perlu membuka koneksi SSE baru per layar.
  final StreamController<MapEntry<String, dynamic>> _events = StreamController.broadcast();
  Stream<MapEntry<String, dynamic>> get events => _events.stream;

  Future<void> start() async {
    await refresh();
    _sub?.cancel();
    _sub = Api.instance.connectEvents().listen(_onEvent);
  }

  void stop() {
    _sub?.cancel();
    Api.instance.closeEvents();
    chats.clear();
  }

  Future<void> refresh() async {
    try {
      final d = await Api.instance.fetchMe();
      final list = (d["chats"] as List).cast<Map<String, dynamic>>();
      chats
        ..clear()
        ..addEntries(list.map((c) => MapEntry(c["id"] as String, c)));
      loading = false;
      error = "";
    } on ApiException catch (e) {
      loading = false;
      error = e.detail;
    }
    notifyListeners();
  }

  void _onEvent(MapEntry<String, dynamic> ev) {
    final data = ev.value as Map<String, dynamic>;
    if (ev.key == "chat" || ev.key == "message") {
      final c = (data["chat"] ?? data) as Map<String, dynamic>;
      if (c["id"] != null) chats[c["id"]] = c;
    } else if (ev.key == "read") {
      final c = chats[data["chatId"]];
      if (c != null && data["user"] == Api.instance.me?["username"]) c["unread"] = 0;
    } else if (ev.key == "presence") {
      for (final c in chats.values) {
        for (final m in (c["members"] as List)) {
          if (m["username"] == data["user"]) m["online"] = data["online"];
        }
      }
    }
    notifyListeners();
    _events.add(ev); // teruskan juga ke layar yang sedang membuka chat tsb.
  }

  List<Map<String, dynamic>> filtered(String q) {
    final list = chats.values.cast<Map<String, dynamic>>().where((c) => c["name"].toString().toLowerCase().contains(q.toLowerCase())).toList();
    list.sort((a, b) {
      final ta = (a["last"]?["ts"] ?? a["created"] ?? 0) as int;
      final tb = (b["last"]?["ts"] ?? b["created"] ?? 0) as int;
      return tb.compareTo(ta);
    });
    return list;
  }

  void upsert(Map<String, dynamic> chat) {
    chats[chat["id"]] = chat;
    notifyListeners();
  }

  @override
  void dispose() {
    _sub?.cancel();
    _events.close();
    super.dispose();
  }
}
