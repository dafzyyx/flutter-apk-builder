import 'package:flutter/material.dart';
import '../core/api.dart';

enum AuthStatus { unknown, loggedOut, loggedIn }

class AuthProvider extends ChangeNotifier {
  AuthStatus status = AuthStatus.unknown;
  Map<String, dynamic>? user;
  String error = "";

  /// Dipanggil sekali saat splash screen, cek token tersimpan.
  Future<void> bootstrap() async {
    await Api.instance.loadToken();
    if (Api.instance.token == null) {
      status = AuthStatus.loggedOut;
      notifyListeners();
      return;
    }
    try {
      final d = await Api.instance.fetchMe();
      user = d["user"];
      status = AuthStatus.loggedIn;
    } catch (_) {
      await Api.instance.logout();
      status = AuthStatus.loggedOut;
    }
    notifyListeners();
  }

  Future<bool> login(String username, String password) => _attempt(() => Api.instance.login(username, password));
  Future<bool> register(String username, String password, String name) => _attempt(() => Api.instance.register(username, password, name));

  Future<bool> _attempt(Future<Map<String, dynamic>> Function() fn) async {
    error = "";
    try {
      final d = await fn();
      user = d["user"];
      status = AuthStatus.loggedIn;
      notifyListeners();
      return true;
    } on ApiException catch (e) {
      error = e.detail;
      notifyListeners();
      return false;
    } catch (e) {
      error = "Terjadi kesalahan: $e";
      notifyListeners();
      return false;
    }
  }

  Future<void> logout() async {
    await Api.instance.logout();
    user = null;
    status = AuthStatus.loggedOut;
    notifyListeners();
  }
}
