import 'package:flutter/material.dart';
import '../core/theme.dart';

/// Kotak bergaya neubrutalism: border tebal + bayangan keras tanpa blur.
class NeuBox extends StatelessWidget {
  final Widget child;
  final Color color;
  final EdgeInsets padding;
  const NeuBox({super.key, required this.child, this.color = Colors.white, this.padding = const EdgeInsets.all(16)});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: color,
        border: Border.all(color: AppColors.ink, width: 2.5),
        boxShadow: const [BoxShadow(color: AppColors.ink, offset: Offset(4, 4), blurRadius: 0)],
      ),
      child: child,
    );
  }
}

class NeuButton extends StatelessWidget {
  final String label;
  final VoidCallback? onTap;
  final Color color;
  const NeuButton({super.key, required this.label, required this.onTap, this.color = AppColors.green});

  @override
  Widget build(BuildContext context) {
    final disabled = onTap == null;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 13),
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: disabled ? const Color(0xFFDDDDDD) : color,
          border: Border.all(color: disabled ? const Color(0xFF999999) : AppColors.ink, width: 2.5),
          boxShadow: disabled ? null : const [BoxShadow(color: AppColors.ink, offset: Offset(3, 3), blurRadius: 0)],
        ),
        child: Text(label.toUpperCase(),
            style: TextStyle(fontWeight: FontWeight.w800, fontSize: 13, letterSpacing: .5, color: disabled ? const Color(0xFF888888) : AppColors.ink)),
      ),
    );
  }
}

class NeuSquareButton extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  const NeuSquareButton({super.key, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 38,
        height: 38,
        alignment: Alignment.center,
        decoration: BoxDecoration(color: Colors.white, border: Border.all(color: AppColors.ink, width: 2)),
        child: Text(label, style: const TextStyle(fontSize: 16)),
      ),
    );
  }
}
