import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const NoruDictionaryApp());
}

class NoruDictionaryApp extends StatefulWidget {
  const NoruDictionaryApp({super.key});

  @override
  State<NoruDictionaryApp> createState() => _NoruDictionaryAppState();
}

class _NoruDictionaryAppState extends State<NoruDictionaryApp> {
  ThemeMode mode = ThemeMode.light;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Noru Japanese Dictionary',
      themeMode: mode,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.light,
        colorSchemeSeed: const Color(0xFFE53935),
        scaffoldBackgroundColor: const Color(0xFFF8F7F3),
        fontFamily: 'sans',
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(18),
            borderSide: BorderSide.none,
          ),
        ),
      ),
      darkTheme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        colorSchemeSeed: const Color(0xFFE53935),
        scaffoldBackgroundColor: const Color(0xFF101010),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(18),
            borderSide: BorderSide.none,
          ),
        ),
      ),
      home: DictionaryPage(
        onToggleTheme: () => setState(() {
          mode = mode == ThemeMode.dark ? ThemeMode.light : ThemeMode.dark;
        }),
      ),
    );
  }
}

class DictionaryPage extends StatefulWidget {
  final VoidCallback onToggleTheme;
  const DictionaryPage({super.key, required this.onToggleTheme});

  @override
  State<DictionaryPage> createState() => _DictionaryPageState();
}

class _DictionaryPageState extends State<DictionaryPage> {
  final searchController = TextEditingController();
  final tts = FlutterTts();

  List<WordEntry> results = [];
  List<String> history = [];
  Set<String> favorites = {};
  bool loading = false;
  String? error;
  String selectedMode = 'words';

  @override
  void initState() {
    super.initState();
    _loadLocal();
    tts.setLanguage('ja-JP');
    tts.setSpeechRate(0.42);
  }

  Future<void> _loadLocal() async {
    final p = await SharedPreferences.getInstance();
    setState(() {
      history = p.getStringList('history') ?? [];
      favorites = (p.getStringList('favorites') ?? []).toSet();
    });
  }

  Future<void> _saveLocal() async {
    final p = await SharedPreferences.getInstance();
    await p.setStringList('history', history);
    await p.setStringList('favorites', favorites.toList());
  }

  Future<void> search([String? value]) async {
    final q = (value ?? searchController.text).trim();
    if (q.isEmpty) return;

    FocusManager.instance.primaryFocus?.unfocus();
    setState(() {
      loading = true;
      error = null;
      results = [];
    });

    try {
      final uri = Uri.parse(
        'https://jisho.org/api/v1/search/words?keyword=${Uri.encodeQueryComponent(q)}',
      );
      final response = await http.get(uri).timeout(const Duration(seconds: 15));

      if (response.statusCode != 200) {
        throw Exception('API mengembalikan status ${response.statusCode}');
      }

      final json = jsonDecode(response.body) as Map<String, dynamic>;
      final data = (json['data'] as List<dynamic>? ?? []);
      final parsed = data
          .map((e) => WordEntry.fromJson(e as Map<String, dynamic>))
          .toList();

      setState(() {
        results = parsed;
        loading = false;
      });

      if (!history.contains(q)) {
        history.insert(0, q);
        if (history.length > 12) history = history.take(12).toList();
        await _saveLocal();
      }
    } catch (e) {
      setState(() {
        loading = false;
        error = 'Gagal mengambil data. Coba lagi beberapa saat lagi.';
      });
    }
  }

  Future<void> randomWord() async {
    const words = [
      '日本', '学校', '先生', '友達', '猫', '犬', '水', '食べる',
      '飲む', '行く', '見る', '好き', 'ありがとう', 'こんにちは',
      '大丈夫', '勉強', '時間', '家', '電車', '音楽'
    ];
    words.shuffle();
    searchController.text = words.first;
    await search(words.first);
  }

  Future<void> speak(String text) async {
    await tts.stop();
    await tts.speak(text);
  }

  Future<void> toggleFavorite(WordEntry word) async {
    final key = word.primary;
    setState(() {
      if (favorites.contains(key)) {
        favorites.remove(key);
      } else {
        favorites.add(key);
      }
    });
    await _saveLocal();
  }

  void showHistory() {
    showModalBottomSheet(
      context: context,
      showDragHandle: true,
      builder: (_) => SafeArea(
        child: history.isEmpty
            ? const Padding(
                padding: EdgeInsets.all(30),
                child: Center(child: Text('Belum ada riwayat pencarian.')),
              )
            : ListView(
                shrinkWrap: true,
                children: [
                  const Padding(
                    padding: EdgeInsets.fromLTRB(20, 4, 20, 10),
                    child: Text(
                      'Riwayat',
                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
                    ),
                  ),
                  ...history.map(
                    (h) => ListTile(
                      leading: const Icon(Icons.history),
                      title: Text(h),
                      onTap: () {
                        Navigator.pop(context);
                        searchController.text = h;
                        search(h);
                      },
                    ),
                  ),
                ],
              ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        titleSpacing: 18,
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('日本語辞典', style: TextStyle(fontWeight: FontWeight.w900)),
            Text('Noru Japanese Dictionary',
                style: TextStyle(fontSize: 11, fontWeight: FontWeight.w500)),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Riwayat',
            onPressed: showHistory,
            icon: const Icon(Icons.history_rounded),
          ),
          IconButton(
            tooltip: 'Mode',
            onPressed: widget.onToggleTheme,
            icon: const Icon(Icons.dark_mode_outlined),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: () => search(),
          child: ListView(
            padding: const EdgeInsets.fromLTRB(18, 8, 18, 30),
            children: [
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: cs.primary,
                  borderRadius: BorderRadius.circular(28),
                ),
                child: const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Kamus Jepang', style: TextStyle(
                      color: Colors.white, fontSize: 28, fontWeight: FontWeight.w900)),
                    SizedBox(height: 6),
                    Text('Cari kanji, kana, romaji, atau arti bahasa Inggris.',
                      style: TextStyle(color: Colors.white70)),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: searchController,
                textInputAction: TextInputAction.search,
                onSubmitted: (_) => search(),
                decoration: InputDecoration(
                  hintText: 'Contoh: 日本 / neko / water...',
                  prefixIcon: const Icon(Icons.search_rounded),
                  suffixIcon: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        tooltip: 'Acak',
                        onPressed: randomWord,
                        icon: const Icon(Icons.casino_outlined),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(right: 6),
                        child: FilledButton(
                          onPressed: loading ? null : search,
                          child: const Text('Cari'),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  _chip('Kata', 'words'),
                  _chip('Kanji', 'kanji'),
                  _chip('Favorit', 'favorites'),
                ],
              ),
              const SizedBox(height: 20),
              if (loading)
                const Padding(
                  padding: EdgeInsets.all(30),
                  child: Center(child: CircularProgressIndicator()),
                )
              else if (error != null)
                _errorCard()
              else if (selectedMode == 'favorites')
                _favoriteView()
              else if (results.isEmpty)
                _emptyView()
              else
                ...results.map(_wordCard),
            ],
          ),
        ),
      ),
    );
  }

  Widget _chip(String label, String value) {
    final active = selectedMode == value;
    return ChoiceChip(
      label: Text(label),
      selected: active,
      onSelected: (_) => setState(() => selectedMode = value),
    );
  }

  Widget _emptyView() {
    return const Padding(
      padding: EdgeInsets.symmetric(vertical: 45),
      child: Column(
        children: [
          Text('日本語', style: TextStyle(fontSize: 46, fontWeight: FontWeight.w900)),
          SizedBox(height: 12),
          Text('Cari kata Jepang untuk mulai.', textAlign: TextAlign.center),
          SizedBox(height: 6),
          Text('Data diambil secara online dari Jisho API.',
              textAlign: TextAlign.center, style: TextStyle(color: Colors.grey)),
        ],
      ),
    );
  }

  Widget _errorCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const Icon(Icons.cloud_off_rounded, size: 44),
            const SizedBox(height: 10),
            Text(error!, textAlign: TextAlign.center),
            const SizedBox(height: 14),
            FilledButton(onPressed: search, child: const Text('Coba lagi')),
          ],
        ),
      ),
    );
  }

  Widget _favoriteView() {
    final favs = results.where((e) => favorites.contains(e.primary)).toList();
    if (favs.isEmpty) {
      return const Padding(
        padding: EdgeInsets.all(30),
        child: Center(child: Text('Belum ada hasil favorit di sesi ini.\nCari kata lalu tekan ⭐.')),
      );
    }
    return Column(children: favs.map(_wordCard).toList());
  }

  Widget _wordCard(WordEntry word) {
    final isFav = favorites.contains(word.primary);
    return Card(
      margin: const EdgeInsets.only(bottom: 14),
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(word.primary,
                        style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w900)),
                      if (word.reading.isNotEmpty)
                        Text(word.reading,
                          style: TextStyle(
                            fontSize: 17,
                            color: Theme.of(context).colorScheme.primary,
                            fontWeight: FontWeight.w700)),
                    ],
                  ),
                ),
                IconButton(
                  tooltip: 'Salin',
                  onPressed: () async {
                    await Clipboard.setData(ClipboardData(
                      text: '${word.primary} — ${word.reading}',
                    ));
                    if (mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Disalin ke clipboard')),
                      );
                    }
                  },
                  icon: const Icon(Icons.copy_rounded),
                ),
                IconButton(
                  tooltip: 'Dengarkan',
                  onPressed: () => speak(word.reading.isEmpty ? word.primary : word.reading),
                  icon: const Icon(Icons.volume_up_rounded),
                ),
                IconButton(
                  tooltip: 'Favorit',
                  onPressed: () => toggleFavorite(word),
                  icon: Icon(isFav ? Icons.star_rounded : Icons.star_border_rounded),
                ),
              ],
            ),
            const SizedBox(height: 14),
            ...word.senses.asMap().entries.map(
              (entry) => Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 24,
                      height: 24,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: Theme.of(context).colorScheme.primaryContainer,
                        borderRadius: BorderRadius.circular(7),
                      ),
                      child: Text('${entry.key + 1}',
                        style: const TextStyle(fontWeight: FontWeight.w800)),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(entry.value,
                        style: const TextStyle(fontSize: 16, height: 1.4)),
                    ),
                  ],
                ),
              ),
            ),
            if (word.parts.isNotEmpty || word.jlpt.isNotEmpty)
              Wrap(
                spacing: 7,
                runSpacing: 7,
                children: [
                  ...word.parts.map((p) => Chip(
                    visualDensity: VisualDensity.compact,
                    label: Text(p),
                  )),
                  ...word.jlpt.map((j) => Chip(
                    visualDensity: VisualDensity.compact,
                    label: Text(j.toUpperCase()),
                  )),
                ],
              ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    searchController.dispose();
    tts.stop();
    super.dispose();
  }
}

class WordEntry {
  final String primary;
  final String reading;
  final List<String> senses;
  final List<String> parts;
  final List<String> jlpt;

  WordEntry({
    required this.primary,
    required this.reading,
    required this.senses,
    required this.parts,
    required this.jlpt,
  });

  factory WordEntry.fromJson(Map<String, dynamic> json) {
    final japanese = (json['japanese'] as List<dynamic>? ?? []);
    final firstJapanese = japanese.isNotEmpty
        ? japanese.first as Map<String, dynamic>
        : <String, dynamic>{};

    final sensesRaw = (json['senses'] as List<dynamic>? ?? []);
    final defs = <String>[];
    final parts = <String>[];

    for (final raw in sensesRaw) {
      final s = raw as Map<String, dynamic>;
      for (final d in (s['english_definitions'] as List<dynamic>? ?? [])) {
        final text = d.toString();
        if (!defs.contains(text)) defs.add(text);
      }
      for (final p in (s['parts_of_speech'] as List<dynamic>? ?? [])) {
        final text = p.toString();
        if (!parts.contains(text)) parts.add(text);
      }
    }

    return WordEntry(
      primary: (firstJapanese['word'] ?? firstJapanese['reading'] ?? '—').toString(),
      reading: (firstJapanese['reading'] ?? '').toString(),
      senses: defs.take(8).toList(),
      parts: parts.take(4).toList(),
      jlpt: (json['jlpt'] as List<dynamic>? ?? []).map((e) => e.toString()).toList(),
    );
  }
}
