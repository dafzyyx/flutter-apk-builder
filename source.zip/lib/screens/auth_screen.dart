import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/theme.dart';
import '../providers/auth_provider.dart';
import '../providers/chat_provider.dart';
import '../widgets/neu.dart';
import 'home_screen.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  bool register = false;
  bool busy = false;
  final name = TextEditingController();
  final user = TextEditingController();
  final pass = TextEditingController();

  Future<void> submit() async {
    setState(() => busy = true);
    final auth = context.read<AuthProvider>();
    final ok = register ? await auth.register(user.text.trim(), pass.text, name.text.trim()) : await auth.login(user.text.trim(), pass.text);
    if (ok && mounted) {
      await context.read<ChatProvider>().start();
      if (!mounted) return;
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const HomeScreen()));
    }
    if (mounted) setState(() => busy = false);
  }

  @override
  Widget build(BuildContext context) {
    final error = context.watch<AuthProvider>().error;
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                NeuBox(
                  color: AppColors.green,
                  child: const Text("NORU CHAT", textAlign: TextAlign.center, style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900, letterSpacing: 1)),
                ),
                const SizedBox(height: 16),
                Row(children: [
                  Expanded(
                      child: GestureDetector(
                    onTap: () => setState(() => register = false),
                    child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        alignment: Alignment.center,
                        decoration: BoxDecoration(color: !register ? AppColors.yellow : Colors.white, border: Border.all(color: AppColors.ink, width: 2.5)),
                        child: const Text("MASUK", style: TextStyle(fontWeight: FontWeight.w800))),
                  )),
                  const SizedBox(width: 8),
                  Expanded(
                      child: GestureDetector(
                    onTap: () => setState(() => register = true),
                    child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        alignment: Alignment.center,
                        decoration: BoxDecoration(color: register ? AppColors.yellow : Colors.white, border: Border.all(color: AppColors.ink, width: 2.5)),
                        child: const Text("DAFTAR", style: TextStyle(fontWeight: FontWeight.w800))),
                  )),
                ]),
                const SizedBox(height: 14),
                if (register) ...[
                  TextField(controller: name, decoration: const InputDecoration(hintText: "Nama tampilan")),
                  const SizedBox(height: 10),
                ],
                TextField(controller: user, autocorrect: false, decoration: const InputDecoration(hintText: "Username")),
                const SizedBox(height: 10),
                TextField(controller: pass, obscureText: true, decoration: const InputDecoration(hintText: "Password (min 6 karakter)")),
                const SizedBox(height: 10),
                if (error.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: Text(error, style: const TextStyle(color: Colors.red, fontWeight: FontWeight.w700)),
                  ),
                NeuButton(label: busy ? "Memproses..." : (register ? "Daftar" : "Masuk"), onTap: busy ? null : submit),
                const SizedBox(height: 10),
                const Text(
                  "Pastikan AppConstants.baseUrl sudah diisi di lib/core/constants.dart sebelum build APK.",
                  style: TextStyle(fontSize: 12, color: Colors.black54),
                  textAlign: TextAlign.center,
                ),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}
