import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:record/record.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';
import '../core/api.dart';
import '../core/theme.dart';
import '../providers/chat_provider.dart';

class ChatScreen extends StatefulWidget {
  final String chatId;
  final Map<String, dynamic> initial;
  const ChatScreen({super.key, required this.chatId, required this.initial});
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  late Map<String, dynamic> chat;
  List<dynamic> msgs = [];
  bool loading = true;
  String error = "";
  final textCtl = TextEditingController();
  final scrollCtl = ScrollController();
  StreamSubscription? sub;
  String? typingUser;
  Timer? typingClear;
  final recorder = AudioRecorder();
  bool recording = false;
  final player = AudioPlayer();
  String? playingId;

  @override
  void initState() {
    super.initState();
    chat = widget.initial;
    _load();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      sub = context.read<ChatProvider>().events.listen(_onEvent);
    });
  }

  @override
  void dispose() {
    sub?.cancel();
    textCtl.dispose();
    recorder.dispose();
    player.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final d = await Api.instance.messages(widget.chatId);
      setState(() {
        msgs = d["messages"];
        chat = d["chat"];
        loading = false;
      });
      Api.instance.markRead(widget.chatId);
      WidgetsBinding.instance.addPostFrameCallback((_) => _scrollBottom());
    } on ApiException catch (e) {
      setState(() {
        error = e.detail;
        loading = false;
      });
    }
  }

  void _scrollBottom() {
    if (scrollCtl.hasClients) {
      scrollCtl.animateTo(scrollCtl.position.maxScrollExtent, duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
    }
  }

  void _onEvent(MapEntry<String, dynamic> ev) {
    final data = ev.value as Map<String, dynamic>;
    if (ev.key == "message" && data["chatId"] == widget.chatId) {
      final msg = data["msg"];
      if (!msgs.any((m) => m["id"] == msg["id"])) {
        setState(() {
          msgs.add(msg);
          chat = data["chat"];
        });
        WidgetsBinding.instance.addPostFrameCallback((_) => _scrollBottom());
        if (msg["from"] != Api.instance.me?["username"]) Api.instance.markRead(widget.chatId);
      }
    } else if (ev.key == "read" && data["chatId"] == widget.chatId) {
      setState(() => chat["reads"][data["user"]] = data["ts"]);
    } else if (ev.key == "typing" && data["chatId"] == widget.chatId) {
      setState(() => typingUser = data["user"]);
      typingClear?.cancel();
      typingClear = Timer(const Duration(seconds: 3), () {
        if (mounted) setState(() => typingUser = null);
      });
    } else if (ev.key == "presence") {
      setState(() {
        for (final m in (chat["members"] as List)) {
          if (m["username"] == data["user"]) m["online"] = data["online"];
        }
      });
    }
  }

  Future<void> sendText() async {
    final t = textCtl.text.trim();
    if (t.isEmpty) return;
    textCtl.clear();
    setState(() {});
    try {
      await Api.instance.sendText(widget.chatId, t);
    } on ApiException catch (e) {
      textCtl.text = t;
      _snack(e.detail);
    }
  }

  Future<void> pickImage() async {
    try {
      final x = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 1280, imageQuality: 82);
      if (x == null) return;
      final bytes = await x.readAsBytes();
      final b64 = base64Encode(bytes);
      final mime = x.name.toLowerCase().endsWith(".png") ? "image/png" : "image/jpeg";
      await Api.instance.sendFile(widget.chatId, "data:$mime;base64,$b64");
    } on ApiException catch (e) {
      _snack(e.detail);
    } catch (e) {
      _snack("Gagal mengambil gambar.");
    }
  }

  Future<void> toggleRecord() async {
    if (recording) {
      final path = await recorder.stop();
      setState(() => recording = false);
      if (path == null) return;
      try {
        final bytes = await File(path).readAsBytes();
        if (bytes.length < 800) return;
        final b64 = base64Encode(bytes);
        await Api.instance.sendFile(widget.chatId, "data:audio/mp4;base64,$b64");
      } on ApiException catch (e) {
        _snack(e.detail);
      }
      return;
    }
    if (!await recorder.hasPermission()) {
      _snack("Izinkan akses mikrofon untuk mengirim voice note.");
      return;
    }
    final dir = await getTemporaryDirectory();
    final path = "${dir.path}/vn_${DateTime.now().millisecondsSinceEpoch}.m4a";
    await recorder.start(const RecordConfig(encoder: AudioEncoder.aacLc), path: path);
    setState(() => recording = true);
  }

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg), backgroundColor: AppColors.red));
  }

  String _time(int ts) {
    final d = DateTime.fromMillisecondsSinceEpoch(ts);
    return "${d.hour.toString().padLeft(2, '0')}.${d.minute.toString().padLeft(2, '0')}";
  }

  String _day(int ts) {
    final d = DateTime.fromMillisecondsSinceEpoch(ts);
    final now = DateTime.now();
    final diff = DateTime(now.year, now.month, now.day).difference(DateTime(d.year, d.month, d.day)).inDays;
    if (diff == 0) return "Hari ini";
    if (diff == 1) return "Kemarin";
    return "${d.day}/${d.month}/${d.year}";
  }

  @override
  Widget build(BuildContext context) {
    final me = Api.instance.me?["username"];
    final isGroup = chat["type"] == "group";
    final peer = isGroup ? null : (chat["members"] as List).cast<Map>().firstWhere((m) => m["username"] != me, orElse: () => {});
    final peerRead = isGroup ? 0 : (chat["reads"]?[chat["peer"]] ?? 0);

    return Scaffold(
      body: SafeArea(
        child: Column(children: [
          Container(
            color: AppColors.yellow,
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
            child: Row(children: [
              IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.arrow_back)),
              CircleAvatar(backgroundColor: AppColors.blue, child: Text(chat["name"].toString().characters.first.toUpperCase())),
              const SizedBox(width: 10),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(chat["name"], style: const TextStyle(fontWeight: FontWeight.w800), overflow: TextOverflow.ellipsis),
                  Text(
                    typingUser != null ? "sedang mengetik..." : (isGroup ? "${(chat["members"] as List).length} anggota" : (peer?["online"] == true ? "online" : "offline")),
                    style: TextStyle(fontSize: 12, color: typingUser != null || peer?["online"] == true ? Colors.green[800] : Colors.black54, fontWeight: FontWeight.w600),
                  ),
                ]),
              ),
            ]),
          ),
          const Divider(height: 2, thickness: 2, color: AppColors.ink),
          Expanded(
            child: Container(
              color: AppColors.chatBg,
              child: loading
                  ? const Center(child: CircularProgressIndicator(color: AppColors.ink))
                  : error.isNotEmpty
                      ? Center(child: Text(error))
                      : ListView.builder(
                          controller: scrollCtl,
                          padding: const EdgeInsets.all(12),
                          itemCount: msgs.length,
                          itemBuilder: (_, i) {
                            final m = msgs[i];
                            final mine = m["from"] == me;
                            final showDay = i == 0 || _day(m["ts"]) != _day(msgs[i - 1]["ts"]);
                            return Column(children: [
                              if (showDay)
                                Padding(
                                  padding: const EdgeInsets.symmetric(vertical: 8),
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 3),
                                    decoration: BoxDecoration(color: AppColors.yellow, border: Border.all(color: AppColors.ink, width: 2)),
                                    child: Text(_day(m["ts"]), style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
                                  ),
                                ),
                              Align(
                                alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
                                child: Container(
                                  margin: const EdgeInsets.symmetric(vertical: 3),
                                  constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
                                  padding: const EdgeInsets.fromLTRB(11, 7, 11, 5),
                                  decoration: BoxDecoration(color: mine ? AppColors.green : Colors.white, border: Border.all(color: AppColors.ink, width: 2.5)),
                                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
                                    if (isGroup && !mine) Text((chat["members"] as List).cast<Map>().firstWhere((x) => x["username"] == m["from"], orElse: () => {"name": m["from"]})["name"], style: const TextStyle(color: Color(0xFFD6007A), fontWeight: FontWeight.w700, fontSize: 12)),
                                    if (m["kind"] == "image")
                                      ClipRRect(
                                        child: Image.network(Api.instance.fileUrl(m["file"]), width: 220, fit: BoxFit.cover,
                                            errorBuilder: (_, __, ___) => const SizedBox(width: 220, height: 120, child: Center(child: Text("Gagal memuat gambar")))),
                                      ),
                                    if (m["kind"] == "audio")
                                      Row(mainAxisSize: MainAxisSize.min, children: [
                                        IconButton(
                                          padding: EdgeInsets.zero,
                                          constraints: const BoxConstraints(),
                                          icon: Icon(playingId == m["id"] ? Icons.stop_circle : Icons.play_circle, size: 30),
                                          onPressed: () async {
                                            if (playingId == m["id"]) {
                                              await player.stop();
                                              setState(() => playingId = null);
                                            } else {
                                              await player.play(UrlSource(Api.instance.fileUrl(m["file"])));
                                              setState(() => playingId = m["id"]);
                                              player.onPlayerComplete.first.then((_) {
                                                if (mounted) setState(() => playingId = null);
                                              });
                                            }
                                          },
                                        ),
                                        const SizedBox(width: 6),
                                        const Text("Pesan suara"),
                                      ]),
                                    if (m["kind"] == "text") Text(m["text"]),
                                    const SizedBox(height: 3),
                                    Row(mainAxisSize: MainAxisSize.min, children: [
                                      Text(_time(m["ts"]), style: const TextStyle(fontSize: 11, color: Colors.black54)),
                                      if (mine) ...[
                                        const SizedBox(width: 3),
                                        Icon(Icons.done_all, size: 13, color: (peerRead ?? 0) >= m["ts"] ? Colors.blue : Colors.black45),
                                      ],
                                    ]),
                                  ]),
                                ),
                              ),
                            ]);
                          },
                        ),
            ),
          ),
          Container(
            color: AppColors.blue,
            padding: EdgeInsets.fromLTRB(8, 8, 8, 8 + MediaQuery.of(context).viewPadding.bottom),
            child: Row(children: [
              IconButton(onPressed: pickImage, icon: const Icon(Icons.image)),
              Expanded(
                child: TextField(
                  controller: textCtl,
                  decoration: const InputDecoration(hintText: "Tulis pesan...", isDense: true, contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 10)),
                  onChanged: (v) {
                    Api.instance.typing(widget.chatId);
                    setState(() {});
                  },
                  onSubmitted: (_) => sendText(),
                ),
              ),
              const SizedBox(width: 6),
              textCtl.text.trim().isNotEmpty
                  ? IconButton(onPressed: sendText, icon: const Icon(Icons.send))
                  : IconButton(
                      onPressed: toggleRecord,
                      icon: Icon(recording ? Icons.stop : Icons.mic, color: recording ? AppColors.red : AppColors.ink),
                    ),
            ]),
          ),
        ]),
      ),
    );
  }
}
