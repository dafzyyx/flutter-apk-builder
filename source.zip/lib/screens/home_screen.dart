import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/api.dart';
import '../core/theme.dart';
import '../providers/auth_provider.dart';
import '../providers/chat_provider.dart';
import '../widgets/neu.dart';
import 'auth_screen.dart';
import 'chat_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String q = "";

  void _logout() async {
    context.read<ChatProvider>().stop();
    await context.read<AuthProvider>().logout();
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const AuthScreen()), (_) => false);
  }

  void _openNewChat() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => NewChatSheet(onCreated: (chat) {
        context.read<ChatProvider>().upsert(chat);
        Navigator.of(context).push(MaterialPageRoute(builder: (_) => ChatScreen(chatId: chat["id"], initial: chat)));
      }),
    );
  }

  @override
  Widget build(BuildContext context) {
    final me = context.watch<AuthProvider>().user;
    final chatProv = context.watch<ChatProvider>();
    final list = chatProv.filtered(q);

    return Scaffold(
      body: SafeArea(
        child: Column(children: [
          Container(
            padding: const EdgeInsets.fromLTRB(14, 10, 14, 10),
            color: AppColors.green,
            child: Row(children: [
              CircleAvatar(backgroundColor: AppColors.pink, child: Text((me?["name"] ?? "?").toString().characters.first.toUpperCase())),
              const SizedBox(width: 10),
              Expanded(child: Text(me?["name"] ?? "", style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16), overflow: TextOverflow.ellipsis)),
              NeuSquareButton(label: "➕", onTap: _openNewChat),
              const SizedBox(width: 8),
              NeuSquareButton(
                label: "⏻",
                onTap: () => showDialog(
                  context: context,
                  builder: (_) => AlertDialog(
                    title: const Text("Keluar?"),
                    actions: [
                      TextButton(onPressed: () => Navigator.pop(context), child: const Text("Batal")),
                      TextButton(
                          onPressed: () {
                            Navigator.pop(context);
                            _logout();
                          },
                          child: const Text("Keluar")),
                    ],
                  ),
                ),
              ),
            ]),
          ),
          Container(
            color: AppColors.bg,
            padding: const EdgeInsets.all(10),
            child: TextField(
              decoration: const InputDecoration(hintText: "Cari chat...", isDense: true, contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 10)),
              onChanged: (v) => setState(() => q = v),
            ),
          ),
          const Divider(height: 1, thickness: 2, color: AppColors.ink),
          Expanded(
            child: chatProv.loading
                ? const Center(child: CircularProgressIndicator(color: AppColors.ink))
                : chatProv.error.isNotEmpty
                    ? Center(child: Padding(padding: const EdgeInsets.all(20), child: Text(chatProv.error, textAlign: TextAlign.center)))
                    : list.isEmpty
                        ? const Center(child: Text("Belum ada chat. Ketuk + untuk mulai.", style: TextStyle(fontWeight: FontWeight.w700)))
                        : RefreshIndicator(
                            onRefresh: chatProv.refresh,
                            child: ListView.separated(
                              itemCount: list.length,
                              separatorBuilder: (_, __) => const Divider(height: 1, color: AppColors.ink),
                              itemBuilder: (_, i) {
                                final c = list[i];
                                final last = c["last"];
                                final unread = (c["unread"] ?? 0) as int;
                                return ListTile(
                                  leading: CircleAvatar(backgroundColor: AppColors.blue, child: Text(c["name"].toString().characters.first.toUpperCase())),
                                  title: Text((c["type"] == "group" ? "👥 " : "") + c["name"], style: const TextStyle(fontWeight: FontWeight.w800), maxLines: 1, overflow: TextOverflow.ellipsis),
                                  subtitle: Text(last == null ? "Belum ada pesan" : last["text"] ?? "", maxLines: 1, overflow: TextOverflow.ellipsis),
                                  trailing: unread > 0
                                      ? Container(
                                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                          decoration: BoxDecoration(color: AppColors.green, border: Border.all(color: AppColors.ink, width: 2)),
                                          child: Text("$unread", style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12)),
                                        )
                                      : null,
                                  onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => ChatScreen(chatId: c["id"], initial: c))),
                                );
                              },
                            ),
                          ),
          ),
        ]),
      ),
    );
  }
}

class NewChatSheet extends StatefulWidget {
  final void Function(Map<String, dynamic> chat) onCreated;
  const NewChatSheet({super.key, required this.onCreated});
  @override
  State<NewChatSheet> createState() => _NewChatSheetState();
}

class _NewChatSheetState extends State<NewChatSheet> {
  bool group = false;
  List<dynamic> results = [];
  Map<String, String> picked = {};
  final q = TextEditingController();
  final groupName = TextEditingController();
  String error = "";
  bool busy = false;

  Future<void> search(String v) async {
    try {
      final r = await Api.instance.searchUsers(v);
      setState(() => results = r);
    } catch (_) {}
  }

  Future<void> pickDm(String username) async {
    setState(() => busy = true);
    try {
      final chat = await Api.instance.openDm(username);
      if (mounted) {
        Navigator.pop(context);
        widget.onCreated(chat);
      }
    } on ApiException catch (e) {
      setState(() => error = e.detail);
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> makeGroup() async {
    if (groupName.text.trim().isEmpty || picked.length < 2) {
      setState(() => error = "Isi nama grup dan pilih minimal 2 anggota.");
      return;
    }
    setState(() => busy = true);
    try {
      final chat = await Api.instance.createGroup(groupName.text.trim(), picked.keys.toList());
      if (mounted) {
        Navigator.pop(context);
        widget.onCreated(chat);
      }
    } on ApiException catch (e) {
      setState(() => error = e.detail);
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: Container(
        decoration: const BoxDecoration(color: AppColors.bg, border: Border(top: BorderSide(color: AppColors.ink, width: 3))),
        padding: const EdgeInsets.all(16),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const Text("MULAI CHAT", style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
          const SizedBox(height: 10),
          Row(children: [
            Expanded(
                child: GestureDetector(
              onTap: () => setState(() => group = false),
              child: Container(padding: const EdgeInsets.symmetric(vertical: 10), alignment: Alignment.center, decoration: BoxDecoration(color: !group ? AppColors.yellow : Colors.white, border: Border.all(color: AppColors.ink, width: 2)), child: const Text("Chat")),
            )),
            const SizedBox(width: 8),
            Expanded(
                child: GestureDetector(
              onTap: () => setState(() => group = true),
              child: Container(padding: const EdgeInsets.symmetric(vertical: 10), alignment: Alignment.center, decoration: BoxDecoration(color: group ? AppColors.yellow : Colors.white, border: Border.all(color: AppColors.ink, width: 2)), child: const Text("Grup")),
            )),
          ]),
          const SizedBox(height: 10),
          if (group) ...[
            TextField(controller: groupName, decoration: const InputDecoration(hintText: "Nama grup")),
            const SizedBox(height: 8),
            Wrap(spacing: 6, children: picked.values.map((n) => Chip(label: Text(n), backgroundColor: AppColors.pink)).toList()),
          ],
          TextField(controller: q, decoration: const InputDecoration(hintText: "Cari username / nama..."), onChanged: search),
          const SizedBox(height: 8),
          if (error.isNotEmpty) Text(error, style: const TextStyle(color: Colors.red, fontWeight: FontWeight.w700)),
          ConstrainedBox(
            constraints: const BoxConstraints(maxHeight: 260),
            child: ListView.builder(
              shrinkWrap: true,
              itemCount: results.length,
              itemBuilder: (_, i) {
                final u = results[i];
                final sel = picked.containsKey(u["username"]);
                return ListTile(
                  leading: CircleAvatar(child: Text(u["name"].toString().characters.first.toUpperCase())),
                  title: Text(u["name"]),
                  subtitle: Text("@${u["username"]}" + (u["online"] == true ? " · online" : "")),
                  trailing: group ? Icon(sel ? Icons.check_box : Icons.check_box_outline_blank) : null,
                  onTap: busy
                      ? null
                      : () {
                          if (group) {
                            setState(() => sel ? picked.remove(u["username"]) : picked[u["username"]] = u["name"]);
                          } else {
                            pickDm(u["username"]);
                          }
                        },
                );
              },
            ),
          ),
          if (group) ...[const SizedBox(height: 8), NeuButton(label: busy ? "Memproses..." : "Buat grup", onTap: busy ? null : makeGroup)],
        ]),
      ),
    );
  }
}
