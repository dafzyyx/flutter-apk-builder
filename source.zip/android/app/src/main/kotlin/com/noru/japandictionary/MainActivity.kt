package com.noru.japandictionary

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
